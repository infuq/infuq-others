
#define p printf
#define s scanf

main()
{

clrscr();


getch();
}